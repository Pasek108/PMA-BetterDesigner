<script src="BetterDesigner/Scripts/table_dragging_fix.js"></script>
<script src="BetterDesigner/Scripts/table_squeeze_fix.js"></script>
<script src="BetterDesigner/Scripts/table_buttons_fix.js"></script>
<script src="BetterDesigner/Scripts/boundaries_fix.js"></script>
<script src="BetterDesigner/Scripts/scrolling_fix.js"></script>
<script src="BetterDesigner/Scripts/smooth_relations.js"></script>
<script src="BetterDesigner/Scripts/drag_scrolling.js"></script>
<script src="BetterDesigner/Scripts/screenshot_mode.js"></script>
<script src="BetterDesigner/Scripts/pages_porting.js"></script>

<script src="BetterDesigner/Modal.js"></script>
<script src="BetterDesigner/BetterDesigner.js"></script>